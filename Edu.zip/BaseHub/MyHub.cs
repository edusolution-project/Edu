﻿using BaseHub.Database;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BaseHub
{
    public class MyHub : Hub
    {
        private readonly ChatService _chatService;
        public MyHub(ChatService chatService)
        {
            _chatService = chatService;
        }
        public Task SendToUser(string userId, string message)
        {
            var itemChat = new ChatEntity()
            {
                Content = message,
                IsGroup = false,
                
            };
            return Clients.User(userId).SendAsync("RecieveFromUser",message);
        }

        public override Task OnDisconnectedAsync(Exception exception)
        {
            // offline
            return base.OnDisconnectedAsync(exception);
        }
        public override Task OnConnectedAsync()
        {
            //online
            return base.OnConnectedAsync();
        }
    }
}
